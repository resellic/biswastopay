package com.biswasto.pay.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.biswasto.pay.data.Status
import com.biswasto.pay.data.Store
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private fun dayStart(offsetDays: Int): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    add(Calendar.DAY_OF_YEAR, offsetDays)
}.timeInMillis

@Composable
fun StatsScreen() {
    val items by Store.items.collectAsState()
    val today0 = dayStart(0)
    val today = items.filter { it.receivedAt >= today0 }
    val todayDone = today.filter { it.status == Status.COMPLETED }
    val todayAmt = todayDone.sumOf { it.amount ?: 0.0 }

    // last 7 days (oldest → today), completed amount per day
    val week = (-6..0).map { d ->
        val s = dayStart(d); val e = dayStart(d + 1)
        val label = if (d == 0) "Today" else SimpleDateFormat("EEE", Locale.US).format(Date(s))
        label to items.filter { it.status == Status.COMPLETED && it.receivedAt in s until e }.sumOf { it.amount ?: 0.0 }
    }
    val weekTotal = week.sumOf { it.second }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionCard("Today", badge = { Pill(SimpleDateFormat("d MMM", Locale.US).format(Date()), C.GreenDark, C.GreenBg) }) {
            Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("Completed Amount", money(todayAmt), C.P1, Modifier.weight(1.4f))
                StatBox("Completed", "${todayDone.size}", C.GreenDark, Modifier.weight(1f))
                StatBox("Failed", "${today.count { it.status == Status.FAILED }}", C.Red, Modifier.weight(1f))
            }
        }

        SectionCard("This Week", badge = { Pill(money(weekTotal), C.GreenDark, C.GreenBg) }) {
            val max = (week.maxOf { it.second }).coerceAtLeast(1.0)
            Row(
                Modifier.fillMaxWidth().height(190.dp).padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                week.forEachIndexed { i, (label, v) ->
                    Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        val frac = (v / max).toFloat().coerceIn(0.03f, 1f)
                        Spacer(Modifier.weight((1f - frac).coerceAtLeast(0.0001f)))
                        Text(if (v >= 1000) String.format(Locale.US, "%.1fk", v / 1000) else String.format(Locale.US, "%.0f", v),
                            color = C.Muted, fontSize = 9.sp)
                        Spacer(Modifier.height(3.dp))
                        Canvas(Modifier.fillMaxWidth(.62f).weight(frac)) {
                            val brush = if (i == 6) Brush.verticalGradient(listOf(C.Green, C.GreenDark))
                                        else Brush.verticalGradient(listOf(C.P3, C.P1))
                            drawRoundRect(brush, Offset.Zero, Size(size.width, size.height), CornerRadius(size.width / 3))
                        }
                        Text(label, color = C.Text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
        }

        SectionCard("By Gateway (Today)") {
            val groups = todayDone.groupBy { it.provider }.mapValues { e -> e.value.sumOf { it.amount ?: 0.0 } }
                .toList().sortedByDescending { it.second }
            if (groups.isEmpty()) {
                Text("No completed payments today", color = C.Muted, fontSize = 13.sp, modifier = Modifier.padding(20.dp))
            }
            groups.forEachIndexed { i, (p, v) ->
                if (i > 0) HorizontalDivider(color = C.Border)
                Column(Modifier.padding(horizontal = 16.dp, vertical = 11.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(p, color = C.Text, fontSize = 13.sp)
                        Text(money(v), color = C.Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(6.dp)).background(C.Bg)) {
                        Box(Modifier.fillMaxWidth((v / todayAmt.coerceAtLeast(1.0)).toFloat()).fillMaxHeight()
                            .clip(RoundedCornerShape(6.dp)).background(C.gateway(p)))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatBox(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(C.Bg).padding(10.dp)) {
        Text(label, color = C.Muted, fontSize = 10.5.sp, maxLines = 1)
        Text(value, color = color, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1)
    }
}
