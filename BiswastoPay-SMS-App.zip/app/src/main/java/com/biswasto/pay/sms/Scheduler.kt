package com.biswasto.pay.sms

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.biswasto.pay.data.Prefs
import com.biswasto.pay.data.Status
import com.biswasto.pay.data.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

object Scheduler {
    private val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun syncNow(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(net)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("sync", ExistingWorkPolicy.APPEND_OR_REPLACE, req)
    }

    fun scanNow(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniqueWork("scan_now", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<ScanWorker>().build())
    }

    /** Auto scan: checks the inbox every 15 minutes (Android's minimum) as a safety net. */
    fun schedulePeriodicScan(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<ScanWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("auto_scan", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class ScanWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        InboxScanner.scan(applicationContext)
        if (Store.pending().isNotEmpty()) Scheduler.syncNow(applicationContext)
        Result.success()
    }
}

class SyncWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val ctx = applicationContext
        val token = Prefs.token.value
        if (token.isBlank() || !Prefs.active.value) return@withContext Result.success() // stays Pending until token is active

        var retry = false
        for (r in Store.pending().sortedBy { it.receivedAt }) {
            when (val res = Api.send(token, r.sender, r.body, r.receivedAt)) {
                is Api.Result.BadToken -> {
                    Prefs.setActive(false)
                    Notifier.alert(ctx, "Biswasto Pay is Inactive", "Token rejected by server. Open the app and save a valid token.")
                    return@withContext Result.success()
                }
                is Api.Result.Error -> {
                    Store.update(r.id) { it.copy(reason = "Retrying · ${res.message}") }
                    retry = true
                }
                is Api.Result.Ok -> {
                    val now = System.currentTimeMillis()
                    val (st, reason) = when (res.status) {
                        "paid" -> Status.COMPLETED to ("Payment #" + res.json.optString("payment_id", "") + " paid")
                        "no_match" -> Status.FAILED to "No matching order"
                        "ambiguous" -> Status.FAILED to "Multiple orders match this amount"
                        "not_credit" -> Status.IGNORED to "Not an incoming payment"
                        "no_amount" -> Status.IGNORED to "Amount not found"
                        else -> Status.FAILED to res.status
                    }
                    Store.update(r.id) { it.copy(status = st, reason = reason, webhookAt = if (st == Status.COMPLETED) now else null) }
                    val updated = Store.items.value.firstOrNull { it.id == r.id }
                    if (updated != null && (st == Status.COMPLETED || st == Status.FAILED)) Notifier.payment(ctx, updated, st == Status.COMPLETED)
                }
            }
        }
        if (retry) Result.retry() else Result.success()
    }
}
