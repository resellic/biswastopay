package com.biswasto.pay.sms

/**
 * Strict sender check: only these SMS sender IDs are forwarded.
 * A fake sender such as "NAGAD-BD" or a phone number never matches.
 */
object Parser {
    private val EXACT = mapOf(
        "bkash" to "bKash",
        "nagad" to "Nagad",
        "16216" to "Rocket",
        "rocket" to "Rocket",
        "upay" to "Upay",
        "brac" to "BRAC Bank",
        "bracbank" to "BRAC Bank",
        "sbl" to "Sonali Bank",
        "sonalibank" to "Sonali Bank",
        "sonali" to "Sonali Bank"
    )

    /** Returns the provider name, or null if the sender is not an allowed payment sender. */
    fun provider(sender: String): String? = EXACT[sender.trim().lowercase()]

    private val AMT1 = Regex("""(?:BDT|Tk\.?|৳)\s*([0-9,]+(?:\.[0-9]{1,4})?)""", RegexOption.IGNORE_CASE)
    private val AMT2 = Regex("""([0-9,]+(?:\.[0-9]{1,4})?)\s*(?:BDT|Tk\.?|Taka)""", RegexOption.IGNORE_CASE)
    private val TRX = Regex("""(?:TrxID|TxnID|TxnId|Trx|Transaction ID)[:\s#]*([A-Z0-9]{6,20})""", RegexOption.IGNORE_CASE)
    private val PHONE = Regex("""(?<!\d)(01\d{9})(?!\d)""")
    private val ACC = Regex("""A/C:?\s*([*\dX]{4,})""", RegexOption.IGNORE_CASE)

    fun amount(body: String): Double? {
        val m = AMT1.find(body) ?: AMT2.find(body) ?: return null
        return m.groupValues[1].replace(",", "").toDoubleOrNull()?.takeIf { it > 0.0 }
    }

    fun trx(body: String): String? = TRX.find(body)?.groupValues?.get(1)?.uppercase()

    // Verification codes, OTPs, promo/ad texts, statements etc. — anything that is not
    // an actual "money received" notification. If any of these appear, the SMS is skipped.
    private val NOT_PAYMENT = Regex(
        """verification code|OTP|one time password|do not share|never share|password reset|""" +
        """promo|offer|cashback campaign|dear customer,? your|statement|balance enquiry|""" +
        """mini statement|pin\b|আপনার (?:ওটিপি|ভেরিফিকেশন)""",
        RegexOption.IGNORE_CASE
    )

    // Phrases that indicate money actually landed in the user's account.
    private val IS_CREDIT = Regex(
        """you have received|money received|cash in|payment received|""" +
        """received tk|টাকা পেয়েছেন|গ্রহণ করেছেন|credited""",
        RegexOption.IGNORE_CASE
    )

    /**
     * True only for a genuine incoming-payment SMS: it must look like a credit
     * notification and must not match any known non-payment pattern (OTP, promo, etc).
     */
    fun isIncomingPayment(body: String): Boolean =
        IS_CREDIT.containsMatchIn(body) && !NOT_PAYMENT.containsMatchIn(body)

    fun phone(body: String): String? =
        PHONE.find(body)?.groupValues?.get(1) ?: ACC.find(body)?.groupValues?.get(1)?.let { "A/C $it" }
}
