package com.biswasto.pay.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.biswasto.pay.R

@Composable
fun SplashView() {
    val t = rememberInfiniteTransition(label = "ld")
    val x by t.animateFloat(-16f, 40f, infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Restart), label = "x")
    Box(Modifier.fillMaxSize().background(C.Grad), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo_white), contentDescription = null, modifier = Modifier.size(92.dp))
            Spacer(Modifier.height(16.dp))
            Text("Biswasto Pay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
            Text("SMS Payment Verification", color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
            Spacer(Modifier.height(26.dp))
            Box(Modifier.width(40.dp).height(4.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = .3f))) {
                Box(Modifier.width(16.dp).fillMaxHeight().offset(x = x.dp).clip(RoundedCornerShape(4.dp)).background(Color.White))
            }
        }
    }
}
