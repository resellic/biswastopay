package com.biswasto.pay.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.biswasto.pay.sms.Scheduler

class MainActivity : ComponentActivity() {
    companion object { const val EXTRA_SMS_ID = "sms_id" }

    /** SMS to open in the detail dialog (from a notification tap). */
    private val openSms = mutableStateOf<String?>(null)
    /** Bumped on every resume so permission switches re-read the real system state. */
    private val resumeTick = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen() // system splash: shown only while the app starts, no extra delay
        super.onCreate(savedInstanceState)
        openSms.value = intent?.getStringExtra(EXTRA_SMS_ID)
        setContent {
            AppRoot(
                openSmsId = openSms.value,
                onSmsOpened = { openSms.value = null },
                resumeTick = resumeTick.value
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra(EXTRA_SMS_ID)?.let { openSms.value = it }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.value++
        // Auto scan every time the app is opened.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
            Scheduler.scanNow(this)
        }
        Scheduler.syncNow(this)
    }
}
