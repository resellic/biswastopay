package com.biswasto.pay.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.biswasto.pay.sms.Scheduler

class MainActivity : ComponentActivity() {
    companion object { const val EXTRA_SMS_ID = "sms_id" }

    /** SMS to open in the detail dialog (from a notification tap). */
    private val openSms = mutableStateOf<String?>(null)
    /** Bumped on every resume so permission switches re-read the real system state. */
    private val resumeTick = mutableStateOf(0)

    // Auto-asks for every permission the app needs, right when it's opened.
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            resumeTick.value++
            Scheduler.scanNow(this)
        }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.RECEIVE_SMS
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.READ_SMS
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen() // system splash: shown only while the app starts, no extra delay
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // draw behind the (now transparent) status/nav bars so our own header/footer gradient shows through instead of a separate flat bar color
        openSms.value = intent?.getStringExtra(EXTRA_SMS_ID)
        requestNeededPermissions() // ask for SMS + notification access as soon as the app opens
        setContent {
            AppRoot(
                openSmsId = openSms.value,
                onSmsOpened = { openSms.value = null },
                resumeTick = resumeTick.value
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra(EXTRA_SMS_ID)?.let { openSms.value = it }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.value++
        // Auto scan every time the app is opened.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
            Scheduler.scanNow(this)
        }
        Scheduler.syncNow(this)
    }
}
