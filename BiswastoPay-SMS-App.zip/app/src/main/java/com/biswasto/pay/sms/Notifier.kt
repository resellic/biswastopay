package com.biswasto.pay.sms

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.biswasto.pay.R
import com.biswasto.pay.data.SmsRecord
import com.biswasto.pay.ui.MainActivity

object Notifier {
    const val CH_PAYMENTS = "payments"
    const val CH_ALERTS = "alerts"

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PAYMENTS, "Payments", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Verified and failed payment SMS"
        })
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, "Alerts", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Token and connection problems"
        })
    }

    private fun canPost(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun openApp(ctx: Context, id: String?): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (id != null) putExtra(MainActivity.EXTRA_SMS_ID, id)
        }
        return PendingIntent.getActivity(ctx, id?.hashCode() ?: 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun money(a: Double?) = if (a == null) "" else "৳" + String.format("%,.2f", a)

    fun payment(ctx: Context, r: SmsRecord, completed: Boolean) {
        if (!canPost(ctx)) return
        val title = if (completed) "Payment Completed ${money(r.amount)}" else "Payment Failed ${money(r.amount)}"
        val text = if (completed) "${r.provider} · ${r.trx ?: "—"} · ${r.reason}" else "${r.provider} · ${r.reason}"
        val n = NotificationCompat.Builder(ctx, CH_PAYMENTS)
            .setSmallIcon(R.drawable.ic_notify)
            .setColor(0xFF4F35E8.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, r.id))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(r.id.hashCode(), n) }
    }

    fun alert(ctx: Context, title: String, text: String) {
        if (!canPost(ctx)) return
        val n = NotificationCompat.Builder(ctx, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_notify)
            .setColor(0xFF4F35E8.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, null))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(9001, n) }
    }
}
