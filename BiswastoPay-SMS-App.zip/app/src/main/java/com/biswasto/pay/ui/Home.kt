package com.biswasto.pay.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.biswasto.pay.data.Prefs
import com.biswasto.pay.data.SmsRecord
import com.biswasto.pay.data.Status
import com.biswasto.pay.data.Store
import com.biswasto.pay.sms.Scheduler

@Composable
fun HomeScreen(openSmsId: String?, onSmsOpened: () -> Unit, resumeTick: Int) {
    val ctx = LocalContext.current
    val all by Store.items.collectAsState()
    val active by Prefs.active.collectAsState()
    var filter by rememberSaveable { mutableStateOf("all") }
    var selected by remember { mutableStateOf<SmsRecord?>(null) }

    LaunchedEffect(openSmsId, all) {
        if (openSmsId != null) {
            all.firstOrNull { it.id == openSmsId }?.let { selected = it }
            onSmsOpened()
        }
    }

    val readOk = resumeTick >= 0 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Kpi("Completed", all.count { it.status == Status.COMPLETED }, C.GreenDark, C.Green, Modifier.weight(1f))
                Kpi("Pending", all.count { it.status == Status.PENDING }, C.Orange, C.Orange, Modifier.weight(1f))
                Kpi("Failed", all.count { it.status == Status.FAILED }, C.Red, C.Red, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            SectionCard(
                "Incoming SMS",
                modifier = Modifier.weight(1f).padding(bottom = 12.dp),
                badge = { Pill("${all.size} SMS", C.GreenDark, C.GreenBg) }
            ) {
                ScanLine(active, readOk)
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("all" to "All", "c" to "Completed", "p" to "Pending", "f" to "Failed").forEach { (k, l) ->
                        val on = filter == k
                        Text(
                            l, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold,
                            color = if (on) Color.White else C.P1,
                            modifier = Modifier.clip(RoundedCornerShape(20.dp))
                                .then(if (on) Modifier.background(C.Grad) else Modifier.background(C.Lav))
                                .clickable { filter = k }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                }
                HorizontalDivider(color = C.Border)
                val shown = all.filter {
                    when (filter) {
                        "c" -> it.status == Status.COMPLETED
                        "p" -> it.status == Status.PENDING
                        "f" -> it.status == Status.FAILED
                        else -> true
                    }
                }
                if (shown.isEmpty()) {
                    Box(Modifier.fillMaxWidth().padding(36.dp), contentAlignment = Alignment.Center) {
                        Text("No payment SMS yet", color = C.Muted, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(Modifier.fillMaxWidth()) {
                        items(shown, key = { it.id }) { r ->
                            SmsRow(r) { selected = r }
                            HorizontalDivider(color = C.Border)
                        }
                    }
                }
            }
        }

        Row(
            Modifier.align(Alignment.BottomEnd).padding(end = 26.dp, bottom = 28.dp)
                .shadow(10.dp, RoundedCornerShape(16.dp), spotColor = C.P1)
                .clip(RoundedCornerShape(16.dp)).background(C.Grad)
                .clickable { Scheduler.scanNow(ctx); Scheduler.syncNow(ctx) }
                .padding(horizontal = 16.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Refresh, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Scan Now", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }

    selected?.let { cur ->
        val fresh = all.firstOrNull { it.id == cur.id } ?: cur
        DetailDialog(fresh) { selected = null }
    }
}

@Composable
private fun Kpi(label: String, n: Int, numColor: Color, top: Color, modifier: Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier.shadow(6.dp, shape, spotColor = C.P1.copy(alpha = .3f)).clip(shape).background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().height(3.dp).background(top))
        Text("$n", color = numColor, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, modifier = Modifier.padding(top = 6.dp))
        Text(label, color = C.Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
    }
}

@Composable
private fun ScanLine(active: Boolean, readOk: Boolean) {
    val (dot, color, text) = when {
        !readOk -> Triple(C.Orange, C.Orange, "Auto scan stopped — SMS permission off")
        !active -> Triple(C.Gray, C.Muted, "Auto scan paused — token not active")
        else -> Triple(C.Green, C.GreenDark, "Auto scanning · new SMS sync instantly")
    }
    Row(
        Modifier.fillMaxWidth().background(Color(0xFFF7F6FF)).padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(8.dp))
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SmsRow(r: SmsRecord, onClick: () -> Unit) {
    val (fg, bg) = statusColors(r.status)
    val dot = when (r.status) {
        Status.COMPLETED -> C.Green; Status.PENDING -> C.Orange; Status.FAILED -> C.Red; Status.IGNORED -> C.Gray
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(C.gateway(r.provider)),
                contentAlignment = Alignment.Center
            ) {
                Text(r.provider.take(1), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            }
            Box(
                Modifier.align(Alignment.BottomEnd).offset(x = 3.dp, y = 3.dp).size(15.dp)
                    .clip(CircleShape).background(Color.White).padding(2.5.dp).clip(CircleShape).background(dot)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(r.provider, color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            Text(
                listOfNotNull(r.trx, shortTime(r.receivedAt)).joinToString(" · "),
                color = C.Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(money(r.amount), color = if (r.status == Status.IGNORED) C.Muted else fg,
                fontWeight = FontWeight.ExtraBold, fontSize = 14.5.sp)
            Spacer(Modifier.height(3.dp))
            Pill(statusLabel(r.status), fg, bg, small = true)
        }
    }
}
