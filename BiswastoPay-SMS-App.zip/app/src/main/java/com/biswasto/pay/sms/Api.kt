package com.biswasto.pay.sms

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Api {
    const val ENDPOINT = "https://biswasto.com/api/sms"

    sealed class Result {
        data class Ok(val status: String, val json: JSONObject) : Result()
        object BadToken : Result()
        data class Error(val message: String) : Result()
    }

    private fun iso(ts: Long): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date(ts))

    fun send(token: String, sender: String, body: String, receivedAt: Long): Result {
        val payload = JSONObject()
            .put("token", token)
            .put("sender", sender)
            .put("body", body)
            .put("received_at", iso(receivedAt))
        return post(payload)
    }

    /**
     * Manual approve/reject for an SMS that auto-matching couldn't resolve (no_match / ambiguous).
     * Reuses the same /api/sms endpoint: the "action" field tells the server this is a merchant
     * override rather than a fresh ingest, so it should skip auto-matching and either credit the
     * order directly (approve) or close it out with no credit (reject). The token identifies the
     * merchant, so the server should only allow acting on that merchant's own pending records.
     */
    fun review(token: String, id: String, sender: String, body: String, receivedAt: Long, action: String): Result {
        val payload = JSONObject()
            .put("token", token)
            .put("sender", sender)
            .put("body", body)
            .put("received_at", iso(receivedAt))
            .put("action", action) // "approve" or "reject"
            .put("client_id", id) // local record id, so the server can echo it back if useful
        return post(payload)
    }

    /** Checks the token: an empty body is accepted by the server without creating anything. */
    fun verifyToken(token: String): Result =
        post(JSONObject().put("token", token).put("sender", "").put("body", "").put("received_at", iso(System.currentTimeMillis())))

    private fun post(payload: JSONObject): Result {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 20000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("User-Agent", "BiswastoPay-SMS/1.0")
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray()) }
            val code = conn.responseCode
            if (code == 401) return Result.BadToken
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) return Result.Error("HTTP $code")
            val json = runCatching { JSONObject(text) }.getOrDefault(JSONObject())
            Result.Ok(json.optString("status", "ok"), json)
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        } finally {
            conn?.disconnect()
        }
    }
}
