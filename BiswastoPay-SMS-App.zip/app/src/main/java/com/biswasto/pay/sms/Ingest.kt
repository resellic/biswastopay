package com.biswasto.pay.sms

import android.content.Context
import com.biswasto.pay.data.SmsRecord
import com.biswasto.pay.data.Status
import com.biswasto.pay.data.Store

object Ingest {
    /** Stores an SMS from an allowed sender and queues it for upload. Returns true if new. */
    fun capture(ctx: Context, sender: String, body: String, receivedAt: Long): Boolean {
        val provider = Parser.provider(sender) ?: return false
        // Same SMS can be seen by the receiver and by an inbox scan; sender+body identify it.
        val id = java.security.MessageDigest.getInstance("SHA-1")
            .digest((sender.trim().lowercase() + "|" + body).toByteArray())
            .joinToString("") { "%02x".format(it) }
        val rec = SmsRecord(
            id = id,
            sender = sender,
            body = body,
            receivedAt = receivedAt,
            provider = provider,
            amount = Parser.amount(body),
            trx = Parser.trx(body),
            phone = Parser.phone(body),
            status = Status.PENDING,
            reason = "Waiting to sync",
            webhookAt = null
        )
        val added = Store.add(rec)
        if (added) Scheduler.syncNow(ctx)
        return added
    }
}
