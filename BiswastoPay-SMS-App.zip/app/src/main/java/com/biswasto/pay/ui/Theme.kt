package com.biswasto.pay.ui

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object C {
    val P1 = Color(0xFF4F35E8)
    val P2 = Color(0xFF7B5CF0)
    val P3 = Color(0xFF9F67F7)
    val Lav = Color(0xFFEEEBFE)
    val Green = Color(0xFF00C49A)
    val GreenDark = Color(0xFF008068)
    val GreenBg = Color(0xFFE6FBF5)
    val Orange = Color(0xFFFF6B2B)
    val OrangeBg = Color(0xFFFFF0EA)
    val Red = Color(0xFFF04343)
    val RedBg = Color(0xFFFEF0F0)
    val Ink = Color(0xFF0A0F2C)
    val Text = Color(0xFF2D3561)
    val Muted = Color(0xFF7A82B0)
    val Border = Color(0xFFE5E8F5)
    val Bg = Color(0xFFF5F7FF)
    val Gray = Color(0xFFB7BCD8)
    val GrayBg = Color(0xFFF0F1F7)
    val Grad = Brush.linearGradient(listOf(P1, P2, P3))

    fun gateway(provider: String): Color = when (provider) {
        "bKash" -> Color(0xFFE2136E)
        "Nagad" -> Color(0xFFEC1C24)
        "Rocket" -> Color(0xFF8C3494)
        "Upay" -> Color(0xFF0B5FA5)
        "BRAC Bank" -> Color(0xFF1B4F8C)
        "Sonali Bank" -> Color(0xFF0E7A3E)
        else -> Muted
    }
}
