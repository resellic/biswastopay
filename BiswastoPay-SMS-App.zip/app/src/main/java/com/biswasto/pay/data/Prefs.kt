package com.biswasto.pay.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object Prefs {
    private lateinit var sp: SharedPreferences

    private val _token = MutableStateFlow("")
    val token: StateFlow<String> = _token.asStateFlow()

    /** true only after the server accepted the token */
    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active.asStateFlow()

    private val _autoStart = MutableStateFlow(true)
    val autoStart: StateFlow<Boolean> = _autoStart.asStateFlow()

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("biswasto_prefs", Context.MODE_PRIVATE)
        _token.value = sp.getString("token", "") ?: ""
        _active.value = sp.getBoolean("active", false) && _token.value.isNotBlank()
        _autoStart.value = sp.getBoolean("auto_start", true)
    }

    fun saveToken(t: String) {
        _token.value = t.trim()
        sp.edit().putString("token", t.trim()).apply()
    }

    fun setActive(v: Boolean) {
        _active.value = v
        sp.edit().putBoolean("active", v).apply()
    }

    fun setAutoStart(v: Boolean) {
        _autoStart.value = v
        sp.edit().putBoolean("auto_start", v).apply()
    }

    var lastScanAt: Long
        get() = sp.getLong("last_scan", 0L)
        set(v) { sp.edit().putLong("last_scan", v).apply() }
}
