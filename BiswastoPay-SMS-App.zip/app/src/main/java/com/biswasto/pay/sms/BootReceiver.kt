package com.biswasto.pay.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.biswasto.pay.data.Prefs

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Prefs.init(ctx)
        if (!Prefs.autoStart.value) return
        Scheduler.schedulePeriodicScan(ctx)
        Scheduler.scanNow(ctx)
    }
}
