package com.biswasto.pay.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.rememberCoroutineScope
import com.biswasto.pay.data.Prefs
import com.biswasto.pay.data.SmsRecord
import com.biswasto.pay.data.Status
import com.biswasto.pay.data.Store
import com.biswasto.pay.sms.Api
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun DetailDialog(r: SmsRecord, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var copied by remember { mutableStateOf(false) }
    var showRaw by remember { mutableStateOf(false) }
    var reviewing by remember { mutableStateOf(false) }
    var reviewError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(copied) { if (copied) { delay(1500); copied = false } }

    fun review(action: String) {
        if (reviewing) return
        reviewing = true
        reviewError = null
        scope.launch {
            val token = Prefs.token.value
            val res = withContext(Dispatchers.IO) {
                Api.review(token, r.id, r.sender, r.body, r.receivedAt, action)
            }
            reviewing = false
            when (res) {
                is Api.Result.Ok -> {
                    Store.update(r.id) {
                        if (action == "approve")
                            it.copy(status = Status.COMPLETED, reason = "Manually approved", webhookAt = System.currentTimeMillis())
                        else
                            it.copy(status = Status.IGNORED, reason = "Manually rejected", webhookAt = null)
                    }
                    onClose()
                }
                is Api.Result.BadToken -> reviewError = "Token rejected by server"
                is Api.Result.Error -> reviewError = res.message
            }
        }
    }

    val rows = listOf(
        "Provider" to r.provider,
        "Transaction ID" to (r.trx ?: "—"),
        "Amount" to money(r.amount),
        "Sender" to (r.phone ?: "—"),
        "SMS Received" to timeFmt(r.receivedAt),
        "Synced" to (r.webhookAt?.let { timeFmt(it) } ?: "—"),
        "Status" to statusLabel(r.status)
    )

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.padding(horizontal = 18.dp).fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)).background(Color.White)
                .verticalScroll(rememberScrollState())
        ) {
            // Header — always brand gradient
            Row(
                Modifier.fillMaxWidth().background(C.Grad).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(C.gateway(r.provider)),
                    contentAlignment = Alignment.Center
                ) { Text(r.provider.take(1), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(statusLabel(r.status), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(r.reason, color = Color.White.copy(alpha = .85f), fontSize = 11.5.sp, maxLines = 2)
                }
                Box(
                    Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(Color.White.copy(alpha = .2f)).clickable(onClick = onClose),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Close, "Close", tint = Color.White, modifier = Modifier.size(18.dp)) }
            }

            if (r.amount != null) {
                Text(
                    money(r.amount), color = C.Ink, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(0xFFF5F3FF), Color.White)))
                        .padding(top = 16.dp, bottom = 10.dp)
                )
            } else Spacer(Modifier.height(12.dp))

            Column(
                Modifier.padding(horizontal = 14.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)).border(1.dp, C.Border, RoundedCornerShape(16.dp))
            ) {
                rows.forEachIndexed { i, (k, v) ->
                    if (i > 0) HorizontalDivider(color = C.Border)
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(k, color = C.Muted, fontSize = 13.sp)
                        if (k == "Status") {
                            val (fg, bg) = statusColors(r.status)
                            Pill(v, fg, bg)
                        } else {
                            Text(
                                v, color = if (k == "Transaction ID") C.P1 else C.Ink, fontWeight = FontWeight.Bold, fontSize = 13.5.sp,
                                fontFamily = if (k == "Transaction ID") FontFamily.Monospace else FontFamily.Default,
                                textAlign = TextAlign.End
                            )
                        }
                    }
                }
            }

            Text(
                if (showRaw) "Hide original SMS" else "Show original SMS",
                color = C.P1, fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp).clickable { showRaw = !showRaw }
            )
            if (showRaw) {
                Text(
                    r.body, color = C.Text, fontSize = 12.sp, lineHeight = 17.sp,
                    modifier = Modifier.padding(horizontal = 14.dp).fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp)).background(C.Bg).padding(10.dp)
                )
            }

            if (r.status == Status.FAILED) {
                if (reviewError != null) {
                    Text(
                        reviewError ?: "", color = C.Red, fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                    )
                }
                Row(Modifier.padding(horizontal = 14.dp, vertical = 4.dp).fillMaxWidth()) {
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                            .background(if (reviewing) C.GrayBg else C.RedBg)
                            .clickable(enabled = !reviewing) { review("reject") }
                            .padding(vertical = 13.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("Reject", color = C.Red, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                            .background(if (reviewing) C.GrayBg else C.GreenBg)
                            .clickable(enabled = !reviewing) { review("approve") }
                            .padding(vertical = 13.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (reviewing) CircularProgressIndicator(modifier = Modifier.size(16.dp), color = C.GreenDark, strokeWidth = 2.dp)
                        else Text("Approve", color = C.GreenDark, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            Box(
                Modifier.padding(14.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.Grad)
                    .clickable {
                        val text = rows.joinToString("\n") { "${it.first}: ${it.second}" }
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Payment details", text))
                        copied = true
                    }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(if (copied) "✓ Copied" else "Copy Details", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
            }
        }
    }
}
