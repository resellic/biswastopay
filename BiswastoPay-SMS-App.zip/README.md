# Biswasto Pay SMS (Android)

ফোনে আসা পেমেন্ট SMS (bKash, Nagad, Rocket, Upay, BRAC Bank, Sonali Bank) ধরে `https://biswasto.com/api/sms`-এ পাঠায়।
সার্ভার অর্ডারের সাথে মিলিয়ে অটো Paid করে, আর ফোনে নোটিফিকেশন আসে।

## GitHub থেকে APK বানানো
1. GitHub-এ একটা **Private** রিপোজিটরি খুলুন (সাইনিং কী রিপোতে আছে, তাই Private রাখবেন)।
2. এই ফোল্ডারের সব ফাইল আপলোড করুন (`.github` ফোল্ডারসহ)।
3. **Actions** ট্যাবে "Build APK" নিজে চালু হবে (৫–৮ মিনিট)।
4. শেষ হলে **Releases**-এ `BiswastoPay-SMS-v1.0.x.apk` পাবেন — ফোন থেকে ডাউনলোড করে ইনস্টল করুন।

পরে কোড বদলে আবার push করলে নতুন ভার্সন তৈরি হবে, আগের অ্যাপের উপরেই আপডেট হবে (একই সাইনিং কী)।

## প্রথমবার সেটআপ
1. biswasto.com → Devices থেকে ডিভাইস টোকেন কপি করুন।
2. অ্যাপ → Settings → Change Token → পেস্ট → Save Token। হেডারে **Active** দেখাবে।
3. Permissions-এ সবগুলো চালু করুন (Receive SMS, Read SMS, Notifications, Battery Optimization, Auto Start)।
4. Xiaomi/Oppo/Vivo/Realme ফোনে ফোনের Settings থেকে অ্যাপের "Autostart" আলাদাভাবে চালু করুন।

## কীভাবে কাজ করে
- নতুন SMS এলে সাথে সাথে ধরে সার্ভারে পাঠায় (ইন্টারনেট না থাকলে পরে নিজে আবার চেষ্টা করে)।
- অটো স্ক্যান: অ্যাপ খুললে, ফোন রিস্টার্টের পরে এবং প্রতি ১৫ মিনিটে ইনবক্স স্ক্যান করে মিস হওয়া SMS ধরে।
- শুধু অনুমোদিত সেন্ডার আইডির SMS যায়; নকল সেন্ডার (যেমন "NAGAD-BD") বা ব্যক্তিগত SMS কখনো পাঠানো হয় না।
- টোকেন Active না থাকলে SMS **Pending** থাকে; টোকেন সেভ করলে সব একসাথে সিঙ্ক হয়।
- Completed / Failed হলে ফোনে নোটিফিকেশন আসে; ট্যাপ করলে সেই SMS-এর ডিটেইলস খোলে।
